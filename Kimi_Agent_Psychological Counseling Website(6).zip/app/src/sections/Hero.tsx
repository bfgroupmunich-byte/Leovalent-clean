import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { FloatingParticles } from '@/components/FloatingParticles';
import { Menu, X } from 'lucide-react';

const navItems = [
  { label: 'Home', href: '#hero' },
  { label: 'About', href: '#about' },
  { label: 'Services', href: '#services' },
  { label: 'Approach', href: '#approach' },
  { label: 'Contact', href: '#contact' },
];

export function Hero() {
  const [isLoaded, setIsLoaded] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const heroRef = useRef<HTMLElement>(null);

  useEffect(() => {
    // Trigger entrance animations
    const timer = setTimeout(() => setIsLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <section
      id="hero"
      ref={heroRef}
      className="relative min-h-screen w-full overflow-hidden"
    >
      {/* Background Image with Parallax */}
      <div
        className="absolute inset-0 transition-transform duration-[1500ms] ease-meditation"
        style={{
          transform: isLoaded ? 'scale(1)' : 'scale(1.1)',
          opacity: isLoaded ? 1 : 0,
        }}
      >
        <img
          src="/images/hero-bg.jpg"
          alt="Peaceful meditation"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Gradient Overlay */}
      <div
        className="absolute inset-0 bg-gradient-to-r from-primary/60 via-primary/40 to-transparent transition-opacity duration-1200"
        style={{ opacity: isLoaded ? 1 : 0 }}
      />

      {/* Floating Particles */}
      <FloatingParticles count={5} />

      {/* Navigation */}
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? 'bg-primary/90 backdrop-blur-md py-4'
            : 'bg-transparent py-6'
        }`}
      >
        <div className="container-custom flex items-center justify-between">
          {/* Logo */}
          <a
            href="#hero"
            onClick={(e) => {
              e.preventDefault();
              scrollToSection('#hero');
            }}
            className="font-display text-xl text-white hover:text-secondary transition-colors"
          >
            Dr. Anna Schmidt
          </a>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navItems.map((item, index) => (
              <a
                key={item.label}
                href={item.href}
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection(item.href);
                }}
                className="text-white/80 hover:text-white link-underline transition-colors text-sm"
                style={{
                  opacity: isLoaded ? 1 : 0,
                  transform: isLoaded ? 'translateY(0)' : 'translateY(-20px)',
                  transition: `opacity 400ms cubic-bezier(0.16, 1, 0.3, 1) ${1400 + index * 80}ms, transform 400ms cubic-bezier(0.16, 1, 0.3, 1) ${1400 + index * 80}ms, color 300ms`,
                }}
              >
                {item.label}
              </a>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-white p-2"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        <div
          className={`md:hidden absolute top-full left-0 right-0 bg-primary/95 backdrop-blur-md transition-all duration-300 ${
            isMobileMenuOpen ? 'opacity-100 visible' : 'opacity-0 invisible'
          }`}
        >
          <div className="container-custom py-6 flex flex-col gap-4">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection(item.href);
                }}
                className="text-white/80 hover:text-white transition-colors py-2"
              >
                {item.label}
              </a>
            ))}
          </div>
        </div>
      </nav>

      {/* Hero Content */}
      <div className="relative z-10 min-h-screen flex items-center">
        <div className="container-custom pt-24">
          <div className="max-w-2xl">
            {/* Title */}
            <h1 className="font-display text-display-1 md:text-[72px] text-white leading-tight mb-6">
              <span
                className="block overflow-hidden"
                style={{
                  opacity: isLoaded ? 1 : 0,
                  transform: isLoaded ? 'translateY(0)' : 'translateY(100%)',
                  transition: 'opacity 800ms cubic-bezier(0.16, 1, 0.3, 1) 600ms, transform 800ms cubic-bezier(0.16, 1, 0.3, 1) 600ms',
                }}
              >
                Find Your
              </span>
              <span
                className="block overflow-hidden"
                style={{
                  opacity: isLoaded ? 1 : 0,
                  transform: isLoaded ? 'translateY(0)' : 'translateY(100%)',
                  transition: 'opacity 800ms cubic-bezier(0.16, 1, 0.3, 1) 750ms, transform 800ms cubic-bezier(0.16, 1, 0.3, 1) 750ms',
                }}
              >
                Inner Peace
              </span>
            </h1>

            {/* Description */}
            <p
              className="text-white/80 text-body-lg max-w-lg mb-8 leading-relaxed"
              style={{
                opacity: isLoaded ? 1 : 0,
                filter: isLoaded ? 'blur(0)' : 'blur(8px)',
                transition: 'opacity 600ms cubic-bezier(0.4, 0, 0.2, 1) 1000ms, filter 600ms cubic-bezier(0.4, 0, 0.2, 1) 1000ms',
              }}
            >
              Professional psychological counseling in a safe, supportive environment. 
              Begin your journey to mental wellness today.
            </p>

            {/* CTA Button */}
            <div
              style={{
                opacity: isLoaded ? 1 : 0,
                transform: isLoaded ? 'scale(1)' : 'scale(0.8)',
                transition: 'opacity 500ms cubic-bezier(0.68, -0.15, 0.265, 1.15) 1200ms, transform 500ms cubic-bezier(0.68, -0.15, 0.265, 1.15) 1200ms',
              }}
            >
              <Button
                size="lg"
                className="bg-secondary text-primary hover:bg-secondary-hover btn-glow px-8 py-6 text-base font-medium"
                onClick={() => scrollToSection('#contact')}
              >
                Book a Session
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10"
        style={{
          opacity: isLoaded ? 0.6 : 0,
          transition: 'opacity 600ms ease 1500ms',
        }}
      >
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center pt-2">
          <div className="w-1 h-2 bg-white/60 rounded-full animate-bounce" />
        </div>
      </div>
    </section>
  );
}
