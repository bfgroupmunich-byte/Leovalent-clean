import { useRef, useEffect, useState } from 'react';
import { Quote as QuoteIcon } from 'lucide-react';

export function Quote() {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const element = sectionRef.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(element);
        }
      },
      { threshold: 0.2 }
    );

    observer.observe(element);

    return () => {
      observer.disconnect();
    };
  }, []);

  const quoteWords = "The greatest discovery of my generation is that human beings can change their lives by changing their minds.".split(' ');

  return (
    <section
      ref={sectionRef}
      className="relative py-24 md:py-32 bg-primary overflow-hidden"
    >
      {/* Decorative Quote Marks */}
      <div
        className="absolute top-12 left-8 md:left-16 transition-all duration-800"
        style={{
          opacity: isVisible ? 0.05 : 0,
          transform: isVisible ? 'scale(1) rotate(0deg)' : 'scale(0) rotate(-20deg)',
          transitionTimingFunction: 'cubic-bezier(0.68, -0.15, 0.265, 1.15)',
          transitionDelay: '200ms',
        }}
      >
        <QuoteIcon className="w-32 h-32 md:w-48 md:h-48 text-white" />
      </div>
      <div
        className="absolute bottom-12 right-8 md:right-16 transition-all duration-800"
        style={{
          opacity: isVisible ? 0.05 : 0,
          transform: isVisible ? 'scale(1) rotate(0deg)' : 'scale(0) rotate(20deg)',
          transitionTimingFunction: 'cubic-bezier(0.68, -0.15, 0.265, 1.15)',
          transitionDelay: '300ms',
        }}
      >
        <QuoteIcon className="w-32 h-32 md:w-48 md:h-48 text-white rotate-180" />
      </div>

      {/* Content */}
      <div className="container-custom relative z-10">
        <div className="max-w-4xl mx-auto text-center px-4">
          {/* Quote Text with Word Stagger */}
          <blockquote className="font-display text-display-2 md:text-display-1 text-white leading-tight mb-8">
            {quoteWords.map((word, index) => (
              <span
                key={index}
                className="inline-block mr-[0.3em]"
                style={{
                  opacity: isVisible ? 1 : 0,
                  transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
                  transition: `opacity 400ms cubic-bezier(0.16, 1, 0.3, 1) ${400 + index * 50}ms, transform 400ms cubic-bezier(0.16, 1, 0.3, 1) ${400 + index * 50}ms`,
                }}
              >
                {word}
              </span>
            ))}
          </blockquote>

          {/* Author */}
          <cite
            className="text-white/60 text-body-lg not-italic font-medium block"
            style={{
              opacity: isVisible ? 1 : 0,
              transform: isVisible ? 'translateX(0)' : 'translateX(100px)',
              transition: 'opacity 600ms cubic-bezier(0.7, 0, 0.84, 0) 1200ms, transform 600ms cubic-bezier(0.7, 0, 0.84, 0) 1200ms',
            }}
          >
            — William James
          </cite>
        </div>
      </div>
    </section>
  );
}
