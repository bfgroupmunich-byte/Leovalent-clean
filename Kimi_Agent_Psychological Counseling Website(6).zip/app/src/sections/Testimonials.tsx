import { ScrollReveal } from '@/components/ScrollReveal';
import { TestimonialSlider } from '@/components/TestimonialSlider';

const testimonials = [
  {
    id: 1,
    title: 'Life-Changing Experience',
    quote: 'Working with Dr. Schmidt has been transformative. Her compassionate approach and insightful guidance helped me navigate through the darkest period of my life. I finally feel like myself again.',
    author: 'Sarah M.',
  },
  {
    id: 2,
    title: 'Highly Recommend',
    quote: 'The couples counseling saved our marriage. We learned to communicate in ways we never thought possible. Our relationship is stronger than ever.',
    author: 'Michael & Jennifer T.',
  },
  {
    id: 3,
    title: 'Finally at Peace',
    quote: 'After years of anxiety, I finally found relief. The stress management techniques I learned have become essential tools in my daily life.',
    author: 'David K.',
  },
];

export function Testimonials() {
  return (
    <section className="section-padding bg-primary overflow-hidden">
      <div className="container-custom">
        {/* Section Header */}
        <ScrollReveal className="text-center mb-12">
          <h2 
            className="font-display text-display-2 text-white mb-4"
            style={{
              textShadow: '0 0 40px rgba(176, 217, 165, 0.2)',
            }}
          >
            What Clients Say
          </h2>
        </ScrollReveal>

        {/* Testimonial Slider */}
        <ScrollReveal delay={200}>
          <TestimonialSlider testimonials={testimonials} />
        </ScrollReveal>
      </div>
    </section>
  );
}
