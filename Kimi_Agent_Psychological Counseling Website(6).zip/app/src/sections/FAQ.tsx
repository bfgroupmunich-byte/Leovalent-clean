import { ScrollReveal } from '@/components/ScrollReveal';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const faqItems = [
  {
    question: 'What should I expect in my first session?',
    answer:
      'Your first session is an opportunity for us to get to know each other. We\'ll discuss what brought you to therapy, your history, and your goals. It\'s a safe space to share at your own pace.',
  },
  {
    question: 'How long does therapy typically last?',
    answer:
      'The duration varies depending on your needs and goals. Some clients see significant improvement in 8-12 sessions, while others prefer longer-term support. We\'ll regularly review your progress together.',
  },
  {
    question: 'Is everything I share confidential?',
    answer:
      'Yes, confidentiality is a cornerstone of therapy. Everything discussed remains private, with rare exceptions required by law (imminent harm to self or others).',
  },
  {
    question: 'Do you offer online sessions?',
    answer:
      'Yes, I offer secure video sessions for clients who prefer the convenience of online therapy or are unable to attend in person.',
  },
  {
    question: 'What are your fees and do you accept insurance?',
    answer:
      'Sessions are €120 for 50 minutes. I provide documentation for insurance reimbursement. Sliding scale fees may be available based on financial need.',
  },
];

export function FAQ() {
  return (
    <section className="section-padding bg-stone-50">
      <div className="container-custom">
        <div className="grid lg:grid-cols-5 gap-12 lg:gap-16">
          {/* Left Column - Title */}
          <div className="lg:col-span-2 lg:sticky lg:top-32 lg:self-start">
            <ScrollReveal direction="left">
              <h2 className="font-display text-display-2 text-primary mb-4">
                Frequently Asked Questions
              </h2>
            </ScrollReveal>
            <ScrollReveal delay={100} direction="left">
              <p className="text-muted text-body-lg">
                Find answers to common questions about the therapy process.
              </p>
            </ScrollReveal>
          </div>

          {/* Right Column - Accordion */}
          <div className="lg:col-span-3">
            <Accordion type="single" collapsible className="space-y-4">
              {faqItems.map((item, index) => (
                <ScrollReveal
                  key={index}
                  delay={200 + index * 100}
                  direction="right"
                  distance={30}
                >
                  <AccordionItem
                    value={`item-${index}`}
                    className="bg-white rounded-lg px-6 border-none shadow-sm hover:shadow-md transition-shadow duration-300 group"
                  >
                    <AccordionTrigger className="text-left font-display text-display-6 text-primary hover:text-secondary hover:no-underline py-5 transition-colors duration-300">
                      {item.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-muted text-body pb-5 leading-relaxed">
                      {item.answer}
                    </AccordionContent>
                  </AccordionItem>
                </ScrollReveal>
              ))}
            </Accordion>
          </div>
        </div>
      </div>
    </section>
  );
}
