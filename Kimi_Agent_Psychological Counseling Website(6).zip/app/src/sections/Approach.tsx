import { useRef, useEffect, useState } from 'react';
import { ScrollReveal } from '@/components/ScrollReveal';

const steps = [
  {
    number: '01',
    title: 'Initial Consultation',
    description:
      'We begin with a free 15-minute call to discuss your needs and determine if we\'re a good fit.',
  },
  {
    number: '02',
    title: 'Assessment & Goal Setting',
    description:
      'Together, we\'ll explore your history, current challenges, and establish clear, achievable goals for therapy.',
  },
  {
    number: '03',
    title: 'Personalized Treatment',
    description:
      'Using evidence-based techniques tailored to your unique situation, we\'ll work through challenges and build resilience.',
  },
  {
    number: '04',
    title: 'Ongoing Support',
    description:
      'Regular sessions with progress reviews, adjustments to your treatment plan, and continuous support throughout your journey.',
  },
];

export function Approach() {
  const sectionRef = useRef<HTMLElement>(null);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const section = sectionRef.current;
    if (!section) return;

    const handleScroll = () => {
      const rect = section.getBoundingClientRect();
      const sectionHeight = rect.height;
      const viewportHeight = window.innerHeight;
      
      // Calculate progress based on section position
      const scrollProgress = Math.max(0, Math.min(1, 
        (viewportHeight - rect.top) / (sectionHeight + viewportHeight)
      ));
      
      setProgress(scrollProgress);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section 
      id="approach" 
      ref={sectionRef}
      className="section-padding bg-white overflow-hidden"
    >
      <div className="container-custom">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Image Column - Sticky */}
          <div className="lg:sticky lg:top-32 lg:self-start">
            <ScrollReveal direction="left" distance={50}>
              <div className="relative">
                <div className="overflow-hidden rounded-lg">
                  <img
                    src="/images/approach-session.jpg"
                    alt="Therapy session"
                    className="w-full h-auto object-cover aspect-[4/5]"
                    style={{
                      transform: `scale(${1 + progress * 0.02})`,
                      transition: 'transform 0.1s linear',
                    }}
                  />
                </div>
                
                {/* Decorative Element */}
                <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-secondary/20 rounded-lg -z-10" />
              </div>
            </ScrollReveal>
          </div>

          {/* Content Column */}
          <div>
            {/* Section Header */}
            <ScrollReveal>
              <h2 className="font-display text-display-2 text-primary mb-4">
                My Approach
              </h2>
            </ScrollReveal>
            <ScrollReveal delay={100}>
              <p className="text-muted text-body-lg mb-12">
                A structured, compassionate process designed to support your healing journey.
              </p>
            </ScrollReveal>

            {/* Timeline */}
            <div className="relative">
              {/* Timeline Line */}
              <div className="absolute left-[23px] top-0 bottom-0 w-0.5 bg-stone-200">
                {/* Progress Fill */}
                <div 
                  className="absolute top-0 left-0 w-full bg-secondary transition-all duration-100"
                  style={{ 
                    height: `${progress * 100}%`,
                    transition: 'height 0.1s linear',
                  }}
                />
              </div>

              {/* Steps */}
              <div className="space-y-10">
                {steps.map((step, index) => {
                  const stepProgress = Math.min(1, Math.max(0, (progress * steps.length) - index));
                  const isActive = stepProgress > 0.5;
                  
                  return (
                    <ScrollReveal
                      key={step.number}
                      delay={200 + index * 100}
                      direction="right"
                      distance={30}
                    >
                      <div 
                        className="relative pl-16 group"
                      >
                        {/* Node */}
                        <div 
                          className={`absolute left-0 top-0 w-12 h-12 rounded-full flex items-center justify-center transition-all duration-500 ${
                            isActive 
                              ? 'bg-secondary scale-110' 
                              : 'bg-stone-200'
                          }`}
                          style={{
                            boxShadow: isActive ? '0 0 20px rgba(176, 217, 165, 0.4)' : 'none',
                          }}
                        >
                          <span className={`font-display font-bold transition-colors duration-300 ${
                            isActive ? 'text-primary' : 'text-muted'
                          }`}>
                            {step.number}
                          </span>
                        </div>

                        {/* Content */}
                        <div 
                          className={`transition-opacity duration-500 ${
                            isActive ? 'opacity-100' : 'opacity-60'
                          }`}
                        >
                          <h3 className="font-display text-display-5 text-primary mb-2 group-hover:text-secondary transition-colors duration-300">
                            {step.title}
                          </h3>
                          <p className="text-muted text-body leading-relaxed">
                            {step.description}
                          </p>
                        </div>
                      </div>
                    </ScrollReveal>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
