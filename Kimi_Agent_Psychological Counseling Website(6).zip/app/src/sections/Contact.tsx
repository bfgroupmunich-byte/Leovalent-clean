import { useState } from 'react';
import { ScrollReveal } from '@/components/ScrollReveal';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { MapPin, Phone, Mail, Clock, Send, Check } from 'lucide-react';

const contactInfo = [
  {
    icon: MapPin,
    label: 'Address',
    value: 'Musterstraße 123, 10115 Berlin',
  },
  {
    icon: Phone,
    label: 'Phone',
    value: '+49 (0) 30 1234 5678',
  },
  {
    icon: Mail,
    label: 'Email',
    value: 'kontakt@psychologie-schmidt.de',
  },
  {
    icon: Clock,
    label: 'Hours',
    value: 'Mon-Fri: 9:00 - 18:00',
  },
];

export function Contact() {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({ name: '', email: '', subject: '', message: '' });
    }, 3000);
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  return (
    <section id="contact" className="section-padding bg-white overflow-hidden">
      <div className="container-custom">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Left Column - Image & Info */}
          <div>
            <ScrollReveal direction="left" distance={50}>
              <div className="relative mb-10">
                <div className="overflow-hidden rounded-lg">
                  <img
                    src="/images/contact-office.jpg"
                    alt="Office"
                    className="w-full h-auto object-cover aspect-[4/5]"
                  />
                </div>
                
                {/* Decorative Element */}
                <div className="absolute -bottom-4 -right-4 w-full h-full bg-secondary/20 rounded-lg -z-10" />
              </div>
            </ScrollReveal>

            {/* Contact Info */}
            <div className="space-y-4">
              {contactInfo.map((item, index) => (
                <ScrollReveal
                  key={item.label}
                  delay={400 + index * 100}
                  direction="left"
                  distance={20}
                >
                  <div className="flex items-start gap-4 group">
                    <div className="w-10 h-10 rounded-full bg-secondary/20 flex items-center justify-center flex-shrink-0 group-hover:bg-secondary/30 transition-colors duration-300">
                      <item.icon className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-muted mb-1">{item.label}</p>
                      <p className="text-primary font-medium">{item.value}</p>
                    </div>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>

          {/* Right Column - Form */}
          <div>
            <ScrollReveal>
              <h2 className="font-display text-display-2 text-primary mb-4">
                Get in Touch
              </h2>
            </ScrollReveal>
            <ScrollReveal delay={100}>
              <p className="text-muted text-body-lg mb-10">
                Ready to begin your journey? Reach out to schedule a consultation or ask any questions.
              </p>
            </ScrollReveal>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-6">
                <ScrollReveal delay={200} direction="up" distance={20}>
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm font-medium text-primary">
                      Name
                    </label>
                    <Input
                      id="name"
                      name="name"
                      type="text"
                      placeholder="Your name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border-stone-200 rounded-lg focus:ring-2 focus:ring-secondary/50 focus:border-secondary transition-all duration-300"
                    />
                  </div>
                </ScrollReveal>

                <ScrollReveal delay={300} direction="up" distance={20}>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium text-primary">
                      Email
                    </label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="your@email.com"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border-stone-200 rounded-lg focus:ring-2 focus:ring-secondary/50 focus:border-secondary transition-all duration-300"
                    />
                  </div>
                </ScrollReveal>
              </div>

              <ScrollReveal delay={400} direction="up" distance={20}>
                <div className="space-y-2">
                  <label htmlFor="subject" className="text-sm font-medium text-primary">
                    Subject
                  </label>
                  <Input
                    id="subject"
                    name="subject"
                    type="text"
                    placeholder="What is this about?"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 border-stone-200 rounded-lg focus:ring-2 focus:ring-secondary/50 focus:border-secondary transition-all duration-300"
                  />
                </div>
              </ScrollReveal>

              <ScrollReveal delay={500} direction="up" distance={20}>
                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm font-medium text-primary">
                    Message
                  </label>
                  <Textarea
                    id="message"
                    name="message"
                    placeholder="Tell me about your situation..."
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={5}
                    className="w-full px-4 py-3 border-stone-200 rounded-lg focus:ring-2 focus:ring-secondary/50 focus:border-secondary transition-all duration-300 resize-none"
                  />
                </div>
              </ScrollReveal>

              <ScrollReveal delay={600} direction="up" distance={20}>
                <Button
                  type="submit"
                  size="lg"
                  disabled={isSubmitted}
                  className={`w-full sm:w-auto px-8 py-6 text-base font-medium transition-all duration-500 ${
                    isSubmitted
                      ? 'bg-green-500 hover:bg-green-500'
                      : 'bg-secondary text-primary hover:bg-secondary-hover btn-glow'
                  }`}
                >
                  {isSubmitted ? (
                    <>
                      <Check className="w-5 h-5 mr-2" />
                      Message Sent
                    </>
                  ) : (
                    <>
                      <Send className="w-5 h-5 mr-2" />
                      Send Message
                    </>
                  )}
                </Button>
              </ScrollReveal>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
