import { ScrollReveal } from '@/components/ScrollReveal';

const quickLinks = [
  { label: 'Home', href: '#hero' },
  { label: 'About', href: '#about' },
  { label: 'Services', href: '#services' },
  { label: 'Contact', href: '#contact' },
];

export function Footer() {
  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-primary py-16 md:py-20">
      <div className="container-custom">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          {/* Logo & Tagline */}
          <ScrollReveal direction="up" distance={20}>
            <div>
              <a
                href="#hero"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('#hero');
                }}
                className="font-display text-2xl text-white hover:text-secondary transition-colors duration-300 inline-block mb-3"
              >
                Dr. Anna Schmidt
              </a>
              <p className="text-white/60 text-body">
                Psychologische Beratung
              </p>
            </div>
          </ScrollReveal>

          {/* Quick Links */}
          <ScrollReveal delay={100} direction="up" distance={20}>
            <div>
              <h4 className="font-display text-display-6 text-white mb-4">
                Quick Links
              </h4>
              <ul className="space-y-3">
                {quickLinks.map((link, index) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      onClick={(e) => {
                        e.preventDefault();
                        scrollToSection(link.href);
                      }}
                      className="text-white/60 hover:text-white link-underline transition-colors duration-300 inline-block"
                      style={{
                        animationDelay: `${index * 80}ms`,
                      }}
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </ScrollReveal>

          {/* Contact Info */}
          <ScrollReveal delay={200} direction="up" distance={20}>
            <div>
              <h4 className="font-display text-display-6 text-white mb-4">
                Contact
              </h4>
              <ul className="space-y-3 text-white/60">
                <li>Musterstraße 123</li>
                <li>10115 Berlin</li>
                <li className="pt-2">+49 (0) 30 1234 5678</li>
                <li>kontakt@psychologie-schmidt.de</li>
              </ul>
            </div>
          </ScrollReveal>
        </div>

        {/* Divider */}
        <div className="border-t border-white/10 pt-8">
          <ScrollReveal delay={300}>
            <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-white/40 text-sm">
              <p>© 2024 Dr. Anna Schmidt. All rights reserved.</p>
              <div className="flex gap-6">
                <a href="#" className="hover:text-white transition-colors duration-300">
                  Privacy Policy
                </a>
                <a href="#" className="hover:text-white transition-colors duration-300">
                  Terms of Service
                </a>
              </div>
            </div>
          </ScrollReveal>
        </div>
      </div>
    </footer>
  );
}
