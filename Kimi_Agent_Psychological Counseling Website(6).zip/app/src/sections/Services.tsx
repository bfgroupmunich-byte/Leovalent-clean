import { ScrollReveal } from '@/components/ScrollReveal';
import { User, Heart, Leaf } from 'lucide-react';

const services = [
  {
    icon: User,
    title: 'Individual Therapy',
    description:
      'One-on-one sessions focused on your personal growth, healing, and self-discovery. Together, we\'ll work through challenges and develop strategies for a healthier mindset.',
  },
  {
    icon: Heart,
    title: 'Couples Counseling',
    description:
      'Strengthen your relationship through improved communication, conflict resolution, and deeper connection. Rebuild trust and rediscover each other.',
  },
  {
    icon: Leaf,
    title: 'Stress Management',
    description:
      'Learn practical techniques to manage anxiety, reduce stress, and cultivate inner calm. Develop resilience and coping strategies for life\'s pressures.',
  },
];

export function Services() {
  return (
    <section id="services" className="section-padding bg-stone-50">
      <div className="container-custom">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <ScrollReveal>
            <h2 className="font-display text-display-2 text-primary mb-4">
              Services
            </h2>
          </ScrollReveal>
          <ScrollReveal delay={100}>
            <p className="text-muted text-body-lg">
              I offer a range of therapeutic services tailored to your unique needs and goals.
            </p>
          </ScrollReveal>
        </div>

        {/* Service Cards */}
        <div 
          className="grid md:grid-cols-3 gap-8"
          style={{ perspective: '1000px' }}
        >
          {services.map((service, index) => (
            <ScrollReveal
              key={service.title}
              delay={200 + index * 150}
              direction="up"
              distance={60}
            >
              <div
                className="group bg-white rounded-xl p-8 shadow-card card-3d h-full"
                style={{
                  transformStyle: 'preserve-3d',
                  marginTop: index === 1 ? '30px' : '0',
                }}
              >
                {/* Icon */}
                <div 
                  className="w-14 h-14 rounded-full bg-secondary/20 flex items-center justify-center mb-6 group-hover:bg-secondary/30 transition-colors duration-300"
                  style={{
                    animation: `float 4s ease-in-out infinite`,
                    animationDelay: `${index * 0.5}s`,
                  }}
                >
                  <service.icon className="w-7 h-7 text-primary group-hover:scale-110 transition-transform duration-300" />
                </div>

                {/* Title */}
                <h3 className="font-display text-display-5 text-primary mb-4">
                  {service.title}
                </h3>

                {/* Description */}
                <p className="text-muted text-body leading-relaxed">
                  {service.description}
                </p>

                {/* Hover Border */}
                <div className="absolute inset-0 rounded-xl border-2 border-transparent group-hover:border-secondary/30 transition-colors duration-300 pointer-events-none" />
              </div>
            </ScrollReveal>
          ))}
        </div>
      </div>
    </section>
  );
}
