import { ScrollReveal } from '@/components/ScrollReveal';
import { AnimatedCounter } from '@/components/AnimatedCounter';

const stats = [
  { value: 10, suffix: '+', label: 'Years Experience' },
  { value: 500, suffix: '+', label: 'Clients Helped' },
  { value: 98, suffix: '%', label: 'Satisfaction Rate' },
];

export function About() {
  return (
    <section id="about" className="section-padding bg-white overflow-hidden">
      <div className="container-custom">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Image Column */}
          <ScrollReveal
            direction="left"
            distance={50}
            duration={1000}
            className="relative"
          >
            <div className="relative">
              {/* Main Image */}
              <div className="relative overflow-hidden rounded-lg">
                <img
                  src="/images/about-portrait.jpg"
                  alt="Dr. Anna Schmidt"
                  className="w-full h-auto object-cover aspect-[4/5] hover:scale-[1.02] transition-transform duration-500"
                />
              </div>
              
              {/* Decorative Shadow */}
              <div 
                className="absolute -bottom-4 -right-4 w-full h-full bg-primary/10 rounded-lg -z-10"
                style={{
                  animation: 'float 8s ease-in-out infinite',
                }}
              />
            </div>
          </ScrollReveal>

          {/* Content Column */}
          <div className="lg:pl-8">
            <ScrollReveal delay={100}>
              <h2 className="font-display text-display-2 text-primary mb-6">
                About Me
              </h2>
            </ScrollReveal>

            <ScrollReveal delay={200}>
              <p className="text-muted text-body-lg leading-relaxed mb-4">
                I am a licensed psychologist with over 10 years of experience helping 
                individuals navigate life's challenges. My approach combines evidence-based 
                techniques with compassionate, personalized care.
              </p>
            </ScrollReveal>

            <ScrollReveal delay={300}>
              <p className="text-muted text-body-lg leading-relaxed mb-10">
                I believe that everyone has the capacity for growth and healing. My role 
                is to provide a safe, non-judgmental space where you can explore your 
                thoughts, feelings, and behaviors, and develop the tools you need to live 
                a more fulfilling life.
              </p>
            </ScrollReveal>

            {/* Divider */}
            <ScrollReveal delay={400}>
              <div className="w-24 h-0.5 bg-secondary mb-10" />
            </ScrollReveal>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6">
              {stats.map((stat, index) => (
                <ScrollReveal key={stat.label} delay={500 + index * 100} direction="up" distance={20}>
                  <AnimatedCounter
                    end={stat.value}
                    suffix={stat.suffix}
                    className="text-display-3 md:text-display-2 text-primary"
                    label={stat.label}
                    labelClassName="text-sm text-muted"
                    duration={1200}
                    delay={800 + index * 150}
                  />
                </ScrollReveal>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
