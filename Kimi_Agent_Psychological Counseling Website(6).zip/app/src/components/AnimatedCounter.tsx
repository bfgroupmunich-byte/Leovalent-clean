import { useCountUp } from '@/hooks/useCountUp';
import { useInView } from '@/hooks/useInView';

interface AnimatedCounterProps {
  end: number;
  suffix?: string;
  prefix?: string;
  duration?: number;
  delay?: number;
  className?: string;
  label?: string;
  labelClassName?: string;
}

export function AnimatedCounter({
  end,
  suffix = '',
  prefix = '',
  duration = 1200,
  delay = 0,
  className = '',
  label,
  labelClassName = '',
}: AnimatedCounterProps) {
  const { ref, isInView } = useInView<HTMLDivElement>({ threshold: 0.3 });
  const { displayValue } = useCountUp({
    end,
    duration,
    delay,
    enabled: isInView,
    suffix,
  });

  return (
    <div ref={ref} className="text-center">
      <div className={`font-display font-bold ${className}`}>
        {prefix}{displayValue}
      </div>
      {label && (
        <div className={`mt-2 ${labelClassName}`}>
          {label}
        </div>
      )}
    </div>
  );
}
