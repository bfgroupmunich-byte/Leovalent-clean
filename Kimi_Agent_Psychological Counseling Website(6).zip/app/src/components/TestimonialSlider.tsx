import { useState, useEffect, useCallback } from 'react';
import { ChevronLeft, ChevronRight, Quote } from 'lucide-react';

interface Testimonial {
  id: number;
  title: string;
  quote: string;
  author: string;
}

interface TestimonialSliderProps {
  testimonials: Testimonial[];
  autoAdvanceInterval?: number;
  className?: string;
}

export function TestimonialSlider({
  testimonials,
  autoAdvanceInterval = 6000,
  className = '',
}: TestimonialSliderProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const goToSlide = useCallback((index: number) => {
    if (isTransitioning) return;
    setIsTransitioning(true);
    setCurrentIndex(index);
    setTimeout(() => setIsTransitioning(false), 800);
  }, [isTransitioning]);

  const nextSlide = useCallback(() => {
    goToSlide((currentIndex + 1) % testimonials.length);
  }, [currentIndex, testimonials.length, goToSlide]);

  const prevSlide = useCallback(() => {
    goToSlide((currentIndex - 1 + testimonials.length) % testimonials.length);
  }, [currentIndex, testimonials.length, goToSlide]);

  useEffect(() => {
    const interval = setInterval(nextSlide, autoAdvanceInterval);
    return () => clearInterval(interval);
  }, [nextSlide, autoAdvanceInterval]);

  return (
    <div className={`relative ${className}`}>
      {/* Quote Icon */}
      <div className="flex justify-center mb-8">
        <Quote className="w-12 h-12 text-secondary/40" />
      </div>

      {/* Testimonials */}
      <div className="relative min-h-[280px] md:min-h-[240px]">
        {testimonials.map((testimonial, index) => (
          <div
            key={testimonial.id}
            className={`absolute inset-0 flex flex-col items-center text-center transition-all duration-700 ease-breath-in ${
              index === currentIndex
                ? 'opacity-100 translate-x-0'
                : index < currentIndex
                ? 'opacity-0 -translate-x-12'
                : 'opacity-0 translate-x-12'
            }`}
          >
            <h4 className="font-display text-display-5 text-white mb-6">
              "{testimonial.title}"
            </h4>
            <p className="text-white/80 text-body-lg max-w-2xl mb-8 leading-relaxed">
              {testimonial.quote}
            </p>
            <p className="text-secondary font-medium">{testimonial.author}</p>
          </div>
        ))}
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-center gap-4 mt-8">
        <button
          onClick={prevSlide}
          className="p-2 rounded-full border border-white/20 text-white/60 hover:text-white hover:border-white/40 transition-all duration-300"
          aria-label="Previous testimonial"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        {/* Dots */}
        <div className="flex gap-2">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                index === currentIndex
                  ? 'bg-secondary scale-125'
                  : 'bg-white/30 hover:bg-white/50'
              }`}
              aria-label={`Go to testimonial ${index + 1}`}
            />
          ))}
        </div>

        <button
          onClick={nextSlide}
          className="p-2 rounded-full border border-white/20 text-white/60 hover:text-white hover:border-white/40 transition-all duration-300"
          aria-label="Next testimonial"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
