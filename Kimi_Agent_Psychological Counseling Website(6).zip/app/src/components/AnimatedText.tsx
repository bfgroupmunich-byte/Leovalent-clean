import { useRef, useEffect, useState } from 'react';

interface AnimatedTextProps {
  children: string;
  className?: string;
  delay?: number;
  staggerDelay?: number;
  as?: 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6' | 'p' | 'span';
  splitBy?: 'words' | 'chars';
}

export function AnimatedText({
  children,
  className = '',
  delay = 0,
  staggerDelay = 50,
  as: Component = 'span',
  splitBy = 'words',
}: AnimatedTextProps) {
  const ref = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(element);
        }
      },
      { threshold: 0.1 }
    );

    observer.observe(element);

    return () => {
      observer.disconnect();
    };
  }, []);

  const items = splitBy === 'words' ? children.split(' ') : children.split('');

  return (
    <Component
      ref={ref as any}
      className={`inline-block ${className}`}
    >
      {items.map((item, index) => (
        <span
          key={index}
          className="inline-block"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
            transition: `opacity 400ms cubic-bezier(0.16, 1, 0.3, 1) ${delay + index * staggerDelay}ms, transform 400ms cubic-bezier(0.16, 1, 0.3, 1) ${delay + index * staggerDelay}ms`,
          }}
        >
          {item}
          {splitBy === 'words' && index < items.length - 1 && '\u00A0'}
        </span>
      ))}
    </Component>
  );
}
