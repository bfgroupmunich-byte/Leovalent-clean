import { Hero } from '@/sections/Hero';
import { Quote } from '@/sections/Quote';
import { About } from '@/sections/About';
import { Services } from '@/sections/Services';
import { Approach } from '@/sections/Approach';
import { Testimonials } from '@/sections/Testimonials';
import { FAQ } from '@/sections/FAQ';
import { Contact } from '@/sections/Contact';
import { Footer } from '@/sections/Footer';

function App() {
  return (
    <main className="min-h-screen">
      <Hero />
      <Quote />
      <About />
      <Services />
      <Approach />
      <Testimonials />
      <FAQ />
      <Contact />
      <Footer />
    </main>
  );
}

export default App;
